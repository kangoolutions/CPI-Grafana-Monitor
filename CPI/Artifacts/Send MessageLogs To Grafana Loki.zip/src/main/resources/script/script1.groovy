    import com.sap.gateway.ip.core.customdev.util.Message;
    import java.util.HashMap;
    import java.sql.Timestamp
    
    def Message processData(Message message) {

        def xml = new XmlSlurper(false,false).parse(message.getBody(Reader))

        def json = """{
                        "streams": ["""

        def logEntry = []

        xml.MessageProcessingLog.each { it ->
        def logEntryhere = ""
            logEntryhere += """
    {"stream": {
    "platform\": "cpi",
    "stage": "dev","""

    logEntryhere += "\"type\": \""+it.IntegrationArtifact.Type.text()+"\""
            
            logEntryhere += """
         },
            "values": [
                [
            """
            

            def incomingDate = it.LogEnd.text()
           
           if(incomingDate.size() == "2023-11-06T08:00:01".size()) {
               incomingDate += ".000"
           } 
           
           incomingDate = incomingDate.padRight(23,"0")
           
        
        def incomingStartDate = it.LogStart.text()
           
           if(incomingStartDate.size() == "2023-11-06T08:00:01".size()) {
               incomingStartDate += ".000"
           } 
           
           incomingStartDate = incomingStartDate.padRight(23,"0")
            

            def dateStart = Date.parse("yyyy-MM-dd'T'HH:mm:ss.SSS",incomingStartDate)
            def dateEnd =  Date.parse("yyyy-MM-dd'T'HH:mm:ss.SSS",incomingDate)
            
            def durationInMS = dateEnd.getTime() - dateStart.getTime()
            

            logEntryhere += "\""+dateEnd.getTime()+"000000\","
            logEntryhere += "\"name=${it.IntegrationArtifact.Id.text()} status=${it.Status.text()} custom_status=${it.CustomStatus.text()} log_level=${it.LogLevel.text()} log_start=${it.LogStart.text()} log_end=${it.LogEnd.text()} duration_ms=${durationInMS} application_message_id=${it.ApplicationMessageId.text()} correlation_id=${it.CorrelationId.text()} sender=${it.Sender.text()} receiver=${it.Receiver.text()} package_id=${it.IntegrationArtifact.PackageId.text()} web_link=${it.AlternateWebLink.text()} transaction_id=${it.TransactionId.text()} message_guid=${it.MessageGuid.text()} application_message_type=${it.ApplicationMessageType.text()}"
            
            it.CustomHeaderProperties.MessageProcessingLogCustomHeaderProperty.each{
                customHeader ->
                logEntryhere += " ${customHeader.Name.text()}=${customHeader.Value.text()}"
            }  
            
            logEntryhere += "\"]]}"
            logEntry<< logEntryhere 
        }

        json += logEntry.join(",")
        json += "\n]}"

        println json
        message.setBody(json)
        message.setHeader("Content-Type", "application/json")
        return message;
        }